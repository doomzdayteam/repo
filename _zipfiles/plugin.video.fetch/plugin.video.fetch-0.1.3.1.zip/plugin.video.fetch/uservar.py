''' 
----------Edit required---------
For online xml for sources, edit the host to the url of the file host='http://something.com/sources.xml'
For local xml file, edit the host to local host='local' and call the file 'sources.xml' and place in the folder
please see sample.xml for layout
on line source can be either https or http
'''

# host=''
host='local'