script.module.yt-dlp
====================

Python [yt-dlp](https://github.com/yt-dlp/yt-dlp/) library packed for Kodi.
