'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/scl/fi/65cissflm2ws1zx1wv0gl/builds.txt?rlkey=i1g343ggwn1lm38iofnywiv2k&dl=1'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
